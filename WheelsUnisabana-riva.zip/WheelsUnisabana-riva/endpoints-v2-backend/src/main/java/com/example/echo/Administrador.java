package com.example.echo;

public class Administrador extends Usuario{

	public Administrador() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Administrador(String nombre, String correo, String contrasena, String tipo) {
		super(nombre, correo, contrasena, tipo);
		// TODO Auto-generated constructor stub
	}	
}
