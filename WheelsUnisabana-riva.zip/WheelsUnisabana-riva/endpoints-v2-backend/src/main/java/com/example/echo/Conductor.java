package com.example.echo;

public class Conductor extends Usuario {

	public Conductor() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Conductor(String nombre, String correo, String contrasena, String tipo) {
		super(nombre, correo, contrasena, tipo);
		// TODO Auto-generated constructor stub
	}
	
}
