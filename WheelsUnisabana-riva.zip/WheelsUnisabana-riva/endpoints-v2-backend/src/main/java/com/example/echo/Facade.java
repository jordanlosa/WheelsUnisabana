package com.example.echo;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashMap;

public class Facade {
	/*riva*/
	ArrayList<Reserva> reservas = new ArrayList<Reserva>();
	HashMap<Long,String> sesiones = new HashMap<Long,String>();
	ArrayList<Usuario> usuarios= new ArrayList<Usuario>(); 
	
	
	
}
