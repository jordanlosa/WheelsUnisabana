package com.example.echo;

public interface IUsuario {
	
	public abstract String getNombre();
	public void setNombre(String nombre);
	public String getCorreo();
	public void setCorreo(String correo);
	public String getContrasena();	
	public void setContrasena(String contrasena);
	public String getTipo();
	public void setTipo(String tipo);

}
