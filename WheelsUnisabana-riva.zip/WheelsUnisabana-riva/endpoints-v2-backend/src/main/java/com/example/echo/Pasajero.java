package com.example.echo;

public class Pasajero extends Usuario {

	public Pasajero() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Pasajero(String nombre, String correo, String contrasena, String tipo) {
		super(nombre, correo, contrasena, tipo);
		// TODO Auto-generated constructor stub
	}
}
